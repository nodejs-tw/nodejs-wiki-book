.. raw:: latex

   \setcounter{secnumdepth}{-1}

*****************
Node.js Wiki Book
*****************

本書為 The Little Node.js Book 正體中文版。

授權
====

The Little Node.js Book 採用創用CC姓名標示-非商業性授權。\
**您不必為本書付費。**

The Little Node.js Book book is licensed under the
Attribution-NonCommercial 3.0 Unported license. **You should not have
paid for this book.**

基本上您可以複製、散佈、修改或播放本書，\
但請務必尊重原作者的著作權，\
勿將本書用於商業用途。

您可以在以下網址取得授權條款全文。

http://creativecommons.org/licenses/by-nc/3.0/legalcode

關於作者
========

* Caesar Chi (clonn)
* Fillano Feng (fillano)
* Kyle Lin (lyhcode)

致謝
====

最新版本
========

本書最新的原始碼（中文版）網址如下：

http://github.com/nodejs-tw/the-little-nodejs-book

.. raw:: latex

   \setcounter{secnumdepth}{1}

